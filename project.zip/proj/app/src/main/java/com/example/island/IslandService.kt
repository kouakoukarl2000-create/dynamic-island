package com.example.island

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat

class IslandService : Service() {
    private lateinit var wm: WindowManager
    private var root: FrameLayout? = null
    private lateinit var pill: FrameLayout
    private lateinit var content: LinearLayout
    private val bg = GradientDrawable().apply { setColor(Color.BLACK) }
    private val handler = Handler(Looper.getMainLooper())
    private var expanded = false

    // Réglages : tailles en dp et distance depuis le haut de l'écran
    private val smallW = 120; private val smallH = 35
    private val bigW = 320;   private val bigH = 110
    private val topOffset = 8

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        if (root == null) addIsland()
        return START_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("island", "Dynamic Island", NotificationManager.IMPORTANCE_MIN))
        val n: Notification = NotificationCompat.Builder(this, "island")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Dynamic Island active")
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34)
            ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun addIsland() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            alpha = 0f
            addView(TextClock(context).apply {
                format12Hour = "h:mm"; format24Hour = "HH:mm"
                textSize = 34f; setTextColor(Color.WHITE)
            })
            addView(TextClock(context).apply {
                format12Hour = "EEEE d MMMM"; format24Hour = "EEEE d MMMM"
                textSize = 13f; setTextColor(Color.parseColor("#9A9AA6"))
            })
        }
        pill = FrameLayout(this).apply {
            background = bg
            addView(content, FrameLayout.LayoutParams(-1, -1))
            layoutParams = FrameLayout.LayoutParams(dp(smallW), dp(smallH))
            setOnClickListener { toggle() }
        }
        bg.cornerRadius = dp(smallH) / 2f

        root = FrameLayout(this).apply { addView(pill) }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(topOffset)
        }
        wm.addView(root, lp)
    }

    private fun toggle() {
        expanded = !expanded
        handler.removeCallbacksAndMessages(null)
        val w0 = pill.layoutParams.width; val h0 = pill.layoutParams.height
        val w1 = dp(if (expanded) bigW else smallW)
        val h1 = dp(if (expanded) bigH else smallH)
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 450
            interpolator = OvershootInterpolator(1.1f)
            addUpdateListener {
                val f = it.animatedValue as Float
                val w = (w0 + (w1 - w0) * f).toInt()
                val h = (h0 + (h1 - h0) * f).toInt()
                pill.layoutParams = FrameLayout.LayoutParams(w, h)
                bg.cornerRadius = minOf(h / 2f, dp(34).toFloat())
            }
            start()
        }
        content.animate().alpha(if (expanded) 1f else 0f)
            .setStartDelay(if (expanded) 150 else 0).setDuration(250).start()
        if (expanded) handler.postDelayed({ if (expanded) toggle() }, 5000)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        root?.let { wm.removeView(it) }
        root = null
        super.onDestroy()
    }
}
