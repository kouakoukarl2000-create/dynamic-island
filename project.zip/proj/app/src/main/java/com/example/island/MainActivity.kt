package com.example.island

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
        }
        col.addView(TextView(this).apply {
            text = "Dynamic Island"
            textSize = 24f
        })
        col.addView(Button(this).apply {
            text = "1. Autoriser l'affichage par-dessus les apps"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        })
        col.addView(Button(this).apply {
            text = "2. Afficher l'îlot"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity))
                    startForegroundService(Intent(this@MainActivity, IslandService::class.java))
            }
        })
        col.addView(Button(this).apply {
            text = "Masquer l'îlot"
            setOnClickListener { stopService(Intent(this@MainActivity, IslandService::class.java)) }
        })
        setContentView(col)
    }
}
